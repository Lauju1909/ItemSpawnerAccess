using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;

namespace ItemSpawnerAccess
{
    // ─────────────────────────────────────────────────────────
    //  Tolk-Wrapper – falls RimWorldAccess aktiv ist, nutzen
    //  wir dessen DLL; ansonsten fallen wir auf Messages zurück.
    // ─────────────────────────────────────────────────────────
    public static class TTS
    {
        private static bool _tolkLoaded;
        private static bool _tolkTried;

        [DllImport("Tolk.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Tolk_Load();
        [DllImport("Tolk.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Tolk_Unload();
        [DllImport("Tolk.dll", CallingConvention = CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool Tolk_Output([MarshalAs(UnmanagedType.LPWStr)] string str,
                                               [MarshalAs(UnmanagedType.Bool)] bool interrupt);
        [DllImport("Tolk.dll", CallingConvention = CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool Tolk_IsLoaded();

        private static void EnsureLoaded()
        {
            if (_tolkTried) return;
            _tolkTried = true;
            try
            {
                Tolk_Load();
                _tolkLoaded = Tolk_IsLoaded();
            }
            catch
            {
                _tolkLoaded = false;
            }
        }

        public static void Say(string text, bool interrupt = true)
        {
            if (string.IsNullOrEmpty(text)) return;
            EnsureLoaded();
            if (_tolkLoaded)
            {
                try { Tolk_Output(text, interrupt); return; } catch { }
            }
            // Fallback: Sprachmeldung im Spiel
            Messages.Message(text, MessageTypeDefOf.NeutralEvent, false);
        }
    }

    // ─────────────────────────────────────────────────────────
    //  Barrierefreies Listenmenü (ersetzt FloatMenu komplett)
    // ─────────────────────────────────────────────────────────
    public static class AccessibleWindowlessMenu
    {
        private static string _title;
        private static System.Collections.Generic.List<(string Label, System.Action Action)> _items;
        private static int _selectedIndex;
        private static string _searchString = "";
        
        public static bool IsActive => _items != null;

        public static void Open(string title, System.Collections.Generic.List<(string Label, System.Action Action)> items)
        {
            _title = title;
            _items = items;
            _selectedIndex = 0;
            _searchString = "";
            AnnounceSelected();
        }

        public static void Close()
        {
            _items = null;
        }

        private static void AnnounceSelected()
        {
            if (_items == null || _items.Count == 0) return;
            string prefix = _searchString.Length > 0 ? $"[{_searchString}] " : "";
            TTS.Say($"{prefix}{_items[_selectedIndex].Label}. {_selectedIndex + 1} {Verse.Translator.Translate("ISA_Of")} {_items.Count}");
        }

        public static void HandleInput()
        {
            if (!IsActive) return;

            UnityEngine.Event e = UnityEngine.Event.current;
            if (e.type != UnityEngine.EventType.KeyDown) return;

            UnityEngine.KeyCode key = e.keyCode;

            if (key == UnityEngine.KeyCode.Escape)
            {
                if (_searchString.Length > 0)
                {
                    _searchString = "";
                    TTS.Say("Search cleared.");
                    AnnounceSelected();
                }
                else
                {
                    TTS.Say(Verse.Translator.Translate("ISA_Closed"));
                    Close();
                }
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.Return || key == UnityEngine.KeyCode.KeypadEnter)
            {
                var action = _items[_selectedIndex].Action;
                Close();
                action?.Invoke();
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.UpArrow)
            {
                if (_selectedIndex > 0)
                {
                    _selectedIndex--;
                    AnnounceSelected();
                }
                else
                {
                    TTS.Say(Verse.Translator.Translate("ISA_BoundaryTop"));
                }
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.DownArrow)
            {
                if (_selectedIndex < _items.Count - 1)
                {
                    _selectedIndex++;
                    AnnounceSelected();
                }
                else
                {
                    TTS.Say(Verse.Translator.Translate("ISA_BoundaryBottom"));
                }
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.Home)
            {
                _selectedIndex = 0;
                AnnounceSelected();
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.End)
            {
                _selectedIndex = _items.Count - 1;
                AnnounceSelected();
                e.Use();
                return;
            }

            if (key == UnityEngine.KeyCode.Backspace)
            {
                if (_searchString.Length > 0)
                {
                    _searchString = _searchString.Substring(0, _searchString.Length - 1);
                    if (_searchString.Length == 0)
                        TTS.Say("Search cleared.");
                    else
                        TTS.Say(_searchString);
                }
                e.Use();
                return;
            }

            // Simple typeahead
            char c = e.character;
            if (c != 0 && !char.IsControl(c))
            {
                _searchString += c.ToString().ToLower();
                int match = _items.FindIndex(i => i.Label.ToLower().Contains(_searchString));
                if (match >= 0)
                {
                    _selectedIndex = match;
                    AnnounceSelected();
                }
                else
                {
                    TTS.Say("No match");
                    _searchString = _searchString.Substring(0, _searchString.Length - 1);
                }
                e.Use();
            }
        }
    }

            

    // ─────────────────────────────────────────────────────────
    //  Hilfsmethode: einfaches Menü öffnen
    // ─────────────────────────────────────────────────────────
    public static class MenuHelper
    {
        public static void Open(string title, List<(string, Action)> items)
        {
            if (items == null || items.Count == 0)
            {
                TTS.Say("ISA_NoEntries".Translate());
                Messages.Message("ISA_NoEntries".Translate(), MessageTypeDefOf.RejectInput, false);
                return;
            }
            AccessibleWindowlessMenu.Open(title, items);
        }
    }

    // ─────────────────────────────────────────────────────────
    //  Initialisierung & Tastatur-Listener
    // ─────────────────────────────────────────────────────────
    [StaticConstructorOnStartup]
    public static class ItemSpawnerAccessInit
    {
        static ItemSpawnerAccessInit()
        {
            var go = new GameObject("ItemSpawnerAccessListener");
            UnityEngine.Object.DontDestroyOnLoad(go);
            go.AddComponent<ItemSpawnerAccessListener>();
        }
    }

    public class ItemSpawnerAccessListener : MonoBehaviour
    {
        public void OnGUI()
        {
            if (AccessibleWindowlessMenu.IsActive)
            {
                AccessibleWindowlessMenu.HandleInput();
            }
        }

        public void Update()
        {
            // F11 ohne Modifier
            if (Input.GetKeyDown(KeyCode.F11)
                && !Input.GetKey(KeyCode.LeftShift)  && !Input.GetKey(KeyCode.RightShift)
                && !Input.GetKey(KeyCode.LeftControl) && !Input.GetKey(KeyCode.RightControl)
                && !Input.GetKey(KeyCode.LeftAlt)     && !Input.GetKey(KeyCode.RightAlt)
                && (int)Current.ProgramState == 2)
            {
                OpenMasterMenu();
            }
        }

        // ═══════════════════════════════════════════════════
        //  MASTER-MENÜ (17 Einträge)
        // ═══════════════════════════════════════════════════
        private void OpenMasterMenu()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_Master_ItemSpawner".Translate(),    OpenItemSpawner),
                ("ISA_Master_EventSpawner".Translate(),   OpenEventSpawner),
                ("ISA_Master_PawnEditor".Translate(),     OpenPawnEditor),
                ("ISA_Master_WeatherTime".Translate(),    OpenWeatherTime),
                ("ISA_Master_ResearchFaction".Translate(),OpenResearchFaction),
                ("ISA_Master_Storyteller".Translate(),    OpenStoryteller),
                ("ISA_Master_BaseMapTools".Translate(),   OpenBaseMapTools),
                ("ISA_Master_NeedsMood".Translate(),      OpenNeedsMood),
                ("ISA_Master_ColonyEnemy".Translate(),    OpenColonyEnemy),
                ("ISA_Master_CaravanWorld".Translate(),   OpenCaravanWorld),
                ("ISA_Master_ArchotechMech".Translate(),  OpenArchotechMech),
                ("ISA_Master_SkillMaster".Translate(),    OpenSkillMaster),
                ("ISA_Master_BaseMaintenance".Translate(),OpenBaseMaintenance),
                ("ISA_Master_NatureControl".Translate(),  OpenNatureControl),
                ("ISA_Master_RoyaltyPsycast".Translate(), OpenRoyaltyPsycast),
                ("ISA_Master_BiotechGenetics".Translate(),OpenBiotechGenetics),
                ("ISA_Master_IdeologyBelief".Translate(), OpenIdeologyBelief),
                  ("ISA_Master_AnimalTaming".Translate(), OpenAnimalTaming),
                  ("ISA_Master_FactionManager".Translate(), OpenFactionManager),
                  ("ISA_Master_RaidTrigger".Translate(), OpenRaidTrigger),
              };
            TTS.Say("ISA_MasterMenuOpened".Translate());
            MenuHelper.Open("ISA_MasterMenuTitle".Translate(), items);
        }

        // ═══════════════════════════════════════════════════
        //  1) ITEM SPAWNER
        // ═══════════════════════════════════════════════════
        
        
        
        private void OpenRaidTrigger()
        {
            var items = new System.Collections.Generic.List<(string, System.Action)>
            {
                ("ISA_TriggerRandomRaid".Translate(), () => TriggerRandomRaid()),
            };
            TTS.Say("Raid Trigger Menu");
            AccessibleWindowlessMenu.Open("Raid Trigger", items);
        }

        private void TriggerRandomRaid()
        {
            RimWorld.IncidentParms parms = RimWorld.StorytellerUtility.DefaultParmsNow(RimWorld.IncidentCategoryDefOf.ThreatBig, Verse.Find.CurrentMap);
            parms.forced = true;
            RimWorld.IncidentDefOf.RaidEnemy.Worker.TryExecute(parms);
            TTS.Say("Triggered Enemy Raid.");
        }

        private void OpenFactionManager()
        {
            var items = new System.Collections.Generic.List<(string, System.Action)>
            {
                ("ISA_MakePeaceWithAll".Translate(), () => MakePeaceWithAll()),
                ("ISA_MaxReputationWithAll".Translate(), () => MaxReputationWithAll()),
            };
            TTS.Say("Faction Manager Menu");
            AccessibleWindowlessMenu.Open("Faction Manager", items);
        }

        private void MakePeaceWithAll()
        {
            int count = 0;
            foreach (var faction in Verse.Find.FactionManager.AllFactionsVisible)
            {
                if (faction != RimWorld.Faction.OfPlayer && faction.HostileTo(RimWorld.Faction.OfPlayer))
                {
                    faction.SetRelationDirect(RimWorld.Faction.OfPlayer, RimWorld.FactionRelationKind.Neutral, false);
                    count++;
                }
            }
            TTS.Say($"Made peace with {count} factions.");
        }

        private void MaxReputationWithAll()
        {
            int count = 0;
            foreach (var faction in Verse.Find.FactionManager.AllFactionsVisible)
            {
                if (faction != RimWorld.Faction.OfPlayer && !faction.IsPlayer)
                {
                    faction.TryAffectGoodwillWith(RimWorld.Faction.OfPlayer, 100, true, true, null, null);
                    count++;
                }
            }
            TTS.Say($"Maximized reputation with {count} factions.");
        }

        private void OpenAnimalTaming()
        {
            var items = new System.Collections.Generic.List<(string, System.Action)>
            {
                ("ISA_TameAllAnimals".Translate(), () => TameAllAnimals()),
            };
            TTS.Say("Animal Taming Menu");
            AccessibleWindowlessMenu.Open("Animal Taming", items);
        }

        private void TameAllAnimals()
        {
            if (Verse.Find.CurrentMap == null) return;
            int count = 0;
            foreach (var pawn in Verse.Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (pawn.RaceProps.Animal && pawn.Faction != RimWorld.Faction.OfPlayer)
                {
                    RimWorld.InteractionWorker_RecruitAttempt.DoRecruit(Verse.Find.CurrentMap.mapPawns.FreeColonists.FirstOrDefault(), pawn, out _, out _);
                    count++;
                }
            }
            TTS.Say($"{count} animals tamed.");
        }

        private void OpenItemSpawner()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_Menu_Items".Translate(),    OpenItemCategories),
                ("ISA_Menu_Buildings".Translate(), OpenBuildings),
                ("ISA_Menu_Pawns".Translate(),    OpenPawnKinds),
            };
            MenuHelper.Open("ISA_Master_ItemSpawner".Translate(), items);
        }

        private void OpenItemCategories()
        {
            var roots = DefDatabase<ThingCategoryDef>.AllDefs
                .Where(c => c.parent == null || c == ThingCategoryDefOf.Root)
                .ToList();
            OpenCategoryLevel(roots);
        }

        private void OpenCategoryLevel(List<ThingCategoryDef> cats)
        {
            var items = cats
                .OrderBy(c => c.label ?? c.defName)
                .Select(cat =>
                {
                    string label = GenText.CapitalizeFirst(cat.label ?? cat.defName);
                    Action act = () =>
                    {
                        var sub = new List<(string, Action)>();
                        if (cat.childCategories != null && cat.childCategories.Count > 0)
                            sub.Add(("ISA_SubCategories".Translate(), () => OpenCategoryLevel(cat.childCategories)));
                        if (cat.childThingDefs != null && cat.childThingDefs.Count > 0)
                            sub.Add(("ISA_ItemsInCategory".Translate(), () => OpenThingList(cat.childThingDefs.ToList(), cat.label ?? cat.defName)));
                        if (sub.Count == 0)
                            Messages.Message("ISA_Empty".Translate(), MessageTypeDefOf.RejectInput, false);
                        else if (sub.Count == 1)
                            sub[0].Item2();
                        else
                            MenuHelper.Open(label, sub);
                    };
                    return (label, act);
                }).ToList();

            MenuHelper.Open("ISA_Menu_Items".Translate(), items);
        }

        private void OpenThingList(List<ThingDef> things, string title)
        {
            var items = things
                .OrderBy(d => d.label ?? d.defName)
                .Select(def =>
                {
                    string label = GenText.CapitalizeFirst(def.label ?? def.defName);
                    Action act = () =>
                    {
                        if (def.MadeFromStuff) OpenStuffMenu(def);
                        else Find.WindowStack.Add(new Dialog_SpawnQuantity(def, null, null));
                    };
                    return (label, act);
                }).ToList();

            MenuHelper.Open(title, items);
        }

        private void OpenStuffMenu(ThingDef itemDef)
        {
            var stuffList = DefDatabase<ThingDef>.AllDefs
                .Where(d => d.IsStuff && d.stuffProps != null && d.stuffProps.CanMake(itemDef))
                .OrderBy(d => d.label ?? d.defName)
                .ToList();

            if (stuffList.Count == 0)
            {
                Find.WindowStack.Add(new Dialog_SpawnQuantity(itemDef, null, null));
                return;
            }

            var items = stuffList.Select(stuff =>
            {
                string label = GenText.CapitalizeFirst(stuff.label ?? stuff.defName);
                Action act = () => Find.WindowStack.Add(new Dialog_SpawnQuantity(itemDef, stuff, null));
                return (label, act);
            }).ToList();
            MenuHelper.Open("ISA_SelectMaterial".Translate(), items);
        }

        private void OpenBuildings()
        {
            var list = DefDatabase<ThingDef>.AllDefs
                .Where(d => d.category == ThingCategory.Building && d.BuildableByPlayer)
                .ToList();
            OpenThingList(list, "ISA_Menu_Buildings".Translate());
        }

        private void OpenPawnKinds()
        {
            var items = DefDatabase<PawnKindDef>.AllDefs
                .OrderBy(d => d.label ?? d.defName)
                .Select(pk =>
                {
                    string label = GenText.CapitalizeFirst(pk.label ?? pk.defName);
                    Action act = () => Find.WindowStack.Add(new Dialog_SpawnQuantity(null, null, pk));
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_Menu_Pawns".Translate(), items);
        }

        // ═══════════════════════════════════════════════════
        //  2) EVENT SPAWNER
        // ═══════════════════════════════════════════════════
        private void OpenEventSpawner()
        {
            var allIncidents = DefDatabase<IncidentDef>.AllDefs.ToList();
            var categories = allIncidents
                .Select(i => i.category)
                .Distinct()
                .OrderBy(c => c.label ?? c.defName)
                .ToList();

            var items = categories.Select(cat =>
            {
                string label = GenText.CapitalizeFirst(cat.label ?? cat.defName);
                Action act = () =>
                {
                    var subItems = allIncidents
                        .Where(i => i.category == cat)
                        .OrderBy(i => i.label ?? i.defName)
                        .Select(inc =>
                        {
                            string incLabel = GenText.CapitalizeFirst(inc.label ?? inc.defName);
                            Action incAct = () => TriggerIncident(inc);
                            return (incLabel, incAct);
                        }).ToList();
                    MenuHelper.Open(label, subItems);
                };
                return (label, act);
            }).ToList();

            MenuHelper.Open("ISA_Master_EventSpawner".Translate(), items);
        }

        private void TriggerIncident(IncidentDef def)
        {
            IIncidentTarget target = null;
            if (Find.CurrentMap != null && def.TargetAllowed(Find.CurrentMap))
                target = Find.CurrentMap;
            else if (def.TargetAllowed(Find.World))
                target = Find.World;

            if (target == null)
            {
                Messages.Message("ISA_NoValidTarget".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_NoValidTarget".Translate());
                return;
            }

            IncidentParms parms = StorytellerUtility.DefaultParmsNow(def.category, target);
            if (def.pointsScaleable)
                parms.points = StorytellerUtility.DefaultThreatPointsNow(target);

            if (def.Worker.TryExecute(parms))
            {
                string msg = "ISA_EventTriggered".Translate() + " " + (def.label ?? def.defName);
                Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                TTS.Say(msg);
            }
            else
            {
                Messages.Message("ISA_EventFailed".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_EventFailed".Translate());
            }
        }

        // ═══════════════════════════════════════════════════
        //  3) PAWN EDITOR
        // ═══════════════════════════════════════════════════
        private void OpenPawnEditor()
        {
            var sel = Find.Selector.SingleSelectedThing as Pawn;
            if (sel == null)
            {
                Messages.Message("ISA_NoPawnSelected".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_NoPawnSelected".Translate());
                return;
            }

            var items = new List<(string, Action)>
            {
                ("ISA_HealPawn".Translate(), () => HealPawn(sel)),
            };

            if (sel.skills != null)
                items.Add(("ISA_MaxSkills".Translate(), () => MaxSkills(sel)));

            if (sel.story?.traits != null)
            {
                items.Add(("ISA_AddTrait".Translate(), () => OpenAddTrait(sel)));
                items.Add(("ISA_RemoveTrait".Translate(), () => OpenRemoveTrait(sel)));
            }

            items.Add(("ISA_SetAge".Translate(), () => Find.WindowStack.Add(new Dialog_SetAge(sel))));
            items.Add(("ISA_GiveWeapon".Translate(), () => GiveBestWeapon(sel)));

            MenuHelper.Open("ISA_Master_PawnEditor".Translate() + ": " + sel.LabelShort, items);
        }

        private void HealPawn(Pawn pawn)
        {
            foreach (var h in pawn.health.hediffSet.hediffs.ToList())
            {
                if (h.def.isBad || h is Hediff_MissingPart)
                    pawn.health.RemoveHediff(h);
            }
            string msg = "ISA_Healed".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void MaxSkills(Pawn pawn)
        {
            if (pawn.skills == null) return;
            foreach (var sk in pawn.skills.skills)
            {
                sk.Level = 20;
                sk.passion = Passion.Major;
            }
            string msg = "ISA_SkillsMaxed".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenAddTrait(Pawn pawn)
        {
            var items = DefDatabase<TraitDef>.AllDefs
                .OrderBy(t => t.defName)
                .Select(td =>
                {
                    string label = td.defName;
                    Action act = () =>
                    {
                        if (td.degreeDatas != null && td.degreeDatas.Count > 1)
                        {
                            var degItems = td.degreeDatas.Select(dd =>
                            {
                                string dl = dd.label ?? (td.defName + " (" + dd.degree + ")");
                                Action da = () => AddTrait(pawn, td, dd.degree);
                                return (dl, da);
                            }).ToList();
                            MenuHelper.Open(label, degItems);
                        }
                        else
                        {
                            int deg = td.degreeDatas != null && td.degreeDatas.Count > 0 ? td.degreeDatas[0].degree : 0;
                            AddTrait(pawn, td, deg);
                        }
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_AddTrait".Translate(), items);
        }

        private void AddTrait(Pawn pawn, TraitDef def, int degree)
        {
            if (pawn.story?.traits == null) return;
            if (pawn.story.traits.HasTrait(def))
            {
                Messages.Message("ISA_HasTraitAlready".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_HasTraitAlready".Translate());
                return;
            }
            pawn.story.traits.GainTrait(new Trait(def, degree, false), false);
            pawn.workSettings?.EnableAndInitializeIfNotAlreadyInitialized();
            string msg = "ISA_TraitAdded".Translate() + " " + def.defName;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenRemoveTrait(Pawn pawn)
        {
            if (pawn.story?.traits == null || pawn.story.traits.allTraits.Count == 0)
            {
                Messages.Message("ISA_NoTraits".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_NoTraits".Translate());
                return;
            }
            var items = pawn.story.traits.allTraits.Select(t =>
            {
                string label = t.LabelCap;
                Action act = () =>
                {
                    pawn.story.traits.allTraits.Remove(t);
                    pawn.workSettings?.EnableAndInitializeIfNotAlreadyInitialized();
                    string msg = "ISA_TraitRemoved".Translate() + " " + t.LabelCap;
                    Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                    TTS.Say(msg);
                };
                return (label, act);
            }).ToList();
            MenuHelper.Open("ISA_RemoveTrait".Translate(), items);
        }

        private void GiveBestWeapon(Pawn pawn)
        {
            var weaponDef = DefDatabase<ThingDef>.AllDefs
                .Where(d => d.IsWeapon && !d.MadeFromStuff)
                .OrderByDescending(d => d.GetStatValueAbstract(StatDefOf.MeleeWeapon_AverageDPS))
                .FirstOrDefault();
            if (weaponDef == null)
            {
                TTS.Say("ISA_NoWeaponFound".Translate());
                return;
            }
            var weapon = ThingMaker.MakeThing(weaponDef);
            pawn.equipment?.AddEquipment((ThingWithComps)weapon);
            string msg = "ISA_WeaponGiven".Translate() + " " + (weaponDef.label ?? weaponDef.defName);
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  4) WETTER & ZEIT
        // ═══════════════════════════════════════════════════
        private void OpenWeatherTime()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_ChangeWeather".Translate(), OpenWeatherList),
                ("ISA_ChangeTime".Translate(),   OpenTimeMenu),
                ("ISA_SkipDay".Translate(),       SkipDay),
                ("ISA_SkipSeason".Translate(),    SkipSeason),
            };
            MenuHelper.Open("ISA_Master_WeatherTime".Translate(), items);
        }

        private void OpenWeatherList()
        {
            var items = DefDatabase<WeatherDef>.AllDefs
                .OrderBy(w => w.label ?? w.defName)
                .Select(w =>
                {
                    string label = GenText.CapitalizeFirst(w.label ?? w.defName);
                    Action act = () =>
                    {
                        if (Find.CurrentMap == null)
                        {
                            TTS.Say("ISA_NoValidTarget".Translate());
                            return;
                        }
                        Find.CurrentMap.weatherManager.TransitionTo(w);
                        string msg = "ISA_WeatherChanged".Translate() + " " + w.label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_ChangeWeather".Translate(), items);
        }

        private void OpenTimeMenu()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_TimeMorning".Translate(), () => SetHour(6)),
                ("ISA_TimeNoon".Translate(),    () => SetHour(12)),
                ("ISA_TimeEvening".Translate(), () => SetHour(18)),
                ("ISA_TimeNight".Translate(),   () => SetHour(22)),
            };
            MenuHelper.Open("ISA_ChangeTime".Translate(), items);
        }

        private void SetHour(int h)
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            int dayTick = GenLocalDate.DayTick(Find.CurrentMap);
            int delta   = h * 2500 - dayTick;
            if (delta <= 0) delta += 60000;
            Find.TickManager.DebugSetTicksGame(Find.TickManager.TicksGame + delta);
            string msg = "ISA_TimeChanged".Translate() + " " + h + ":00";
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void SkipDay()
        {
            Find.TickManager.DebugSetTicksGame(Find.TickManager.TicksGame + 60000);
            string msg = "ISA_DaySkipped".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void SkipSeason()
        {
            Find.TickManager.DebugSetTicksGame(Find.TickManager.TicksGame + 900000);
            string msg = "ISA_SeasonSkipped".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  5) FORSCHUNG & FRAKTIONEN
        // ═══════════════════════════════════════════════════
        private void OpenResearchFaction()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_FinishAllResearch".Translate(),  FinishAllResearch),
                ("ISA_FinishOneResearch".Translate(),  OpenFinishOneResearch),
                ("ISA_PeaceWithAll".Translate(),       PeaceWithAll),
                ("ISA_MaxRelations".Translate(),       MaxRelations),
                ("ISA_AddSilver".Translate(),          () => AddResource(ThingDefOf.Silver, 1000)),
            };
            MenuHelper.Open("ISA_Master_ResearchFaction".Translate(), items);
        }

        private void FinishAllResearch()
        {
            foreach (var rp in DefDatabase<ResearchProjectDef>.AllDefs)
                if (!rp.IsFinished)
                    Find.ResearchManager.FinishProject(rp, false, null, true);
            string msg = "ISA_ResearchFinished".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenFinishOneResearch()
        {
            var items = DefDatabase<ResearchProjectDef>.AllDefs
                .Where(r => !r.IsFinished)
                .OrderBy(r => r.label ?? r.defName)
                .Select(r =>
                {
                    string label = GenText.CapitalizeFirst(r.label ?? r.defName);
                    Action act = () =>
                    {
                        Find.ResearchManager.FinishProject(r, false, null, true);
                        string msg = "ISA_ResearchFinishedOne".Translate() + " " + label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_FinishOneResearch".Translate(), items);
        }

        private void PeaceWithAll()
        {
            foreach (var f in Find.FactionManager.AllFactionsListForReading)
            {
                if (f == Faction.OfPlayer || f.def.permanentEnemy || f.Hidden) continue;
                int delta = 50 - f.GoodwillWith(Faction.OfPlayer);
                if (delta > 0)
                    f.TryAffectGoodwillWith(Faction.OfPlayer, delta, false, false, null, null);
            }
            string msg = "ISA_PeaceMade".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void MaxRelations()
        {
            foreach (var f in Find.FactionManager.AllFactionsListForReading)
            {
                if (f == Faction.OfPlayer || f.def.permanentEnemy || f.Hidden) continue;
                int delta = 100 - f.GoodwillWith(Faction.OfPlayer);
                if (delta > 0)
                    f.TryAffectGoodwillWith(Faction.OfPlayer, delta, false, false, null, null);
            }
            string msg = "ISA_RelationsMaxed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void AddResource(ThingDef def, int count)
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var thing = ThingMaker.MakeThing(def);
            thing.stackCount = count;
            GenSpawn.Spawn(thing, DropCellFinder.TradeDropSpot(Find.CurrentMap), Find.CurrentMap);
            string msg = count + "x " + (def.label ?? def.defName) + " " + "ISA_SpawnedSuffix".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  6) STORYTELLER
        // ═══════════════════════════════════════════════════
        private void OpenStoryteller()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_ChangeStoryteller".Translate(), OpenStorytellerList),
                ("ISA_ChangeDifficulty".Translate(),  OpenDifficultyList),
            };
            MenuHelper.Open("ISA_Master_Storyteller".Translate(), items);
        }

        private void OpenStorytellerList()
        {
            var items = DefDatabase<StorytellerDef>.AllDefs
                .OrderBy(s => s.label ?? s.defName)
                .Select(s =>
                {
                    string label = GenText.CapitalizeFirst(s.label ?? s.defName);
                    Action act = () =>
                    {
                        Find.Storyteller.def = s;
                        Find.Storyteller.Notify_DefChanged();
                        string msg = "ISA_StorytellerChanged".Translate() + " " + s.label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_ChangeStoryteller".Translate(), items);
        }

        private void OpenDifficultyList()
        {
            var items = DefDatabase<DifficultyDef>.AllDefs
                .OrderBy(d => d.difficulty)
                .Select(d =>
                {
                    string label = GenText.CapitalizeFirst(d.label ?? d.defName);
                    Action act = () =>
                    {
                        Find.Storyteller.difficulty = new Difficulty(d);
                        string msg = "ISA_DifficultyChanged".Translate() + " " + d.label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_ChangeDifficulty".Translate(), items);
        }

        // ═══════════════════════════════════════════════════
        //  7) BASIS & KARTEN-WERKZEUGE
        // ═══════════════════════════════════════════════════
        private void OpenBaseMapTools()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_ToggleInstantBuild".Translate(), ToggleGodMode),
                ("ISA_ClearFog".Translate(),           ClearFog),
                ("ISA_MaxPlantGrowth".Translate(),     MaxPlantGrowth),
                ("ISA_RemoveAllRoofs".Translate(),     RemoveAllRoofs),
                ("ISA_DestroyAllBlueprints".Translate(),DestroyBlueprints),
            };
            MenuHelper.Open("ISA_Master_BaseMapTools".Translate(), items);
        }

        private void ToggleGodMode()
        {
            DebugSettings.godMode = !DebugSettings.godMode;
            string msg = "ISA_InstantBuildToggled".Translate() + " " + (DebugSettings.godMode ? "ON" : "OFF");
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void ClearFog()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            Find.CurrentMap.fogGrid.ClearAllFog();
            string msg = "ISA_FogCleared".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void MaxPlantGrowth()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var t in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.Plant).ToList())
            {
                if (t is Plant p && p.def.plant != null)
                    p.Growth = 1f;
            }
            string msg = "ISA_PlantsMaximized".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void RemoveAllRoofs()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var area = Find.CurrentMap.cellIndices.NumGridCells;
            for (int i = 0; i < area; i++)
                Find.CurrentMap.roofGrid.SetRoof(Find.CurrentMap.cellIndices.IndexToCell(i), null);
            string msg = "ISA_RoofsRemoved".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void DestroyBlueprints()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var bp in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.Blueprint).ToList())
                bp.Destroy();
            string msg = "ISA_BlueprintsDestroyed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  8) STIMMUNGS-MANAGER
        // ═══════════════════════════════════════════════════
        private void OpenNeedsMood()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_MaxAllNeeds".Translate(),     MaxAllNeeds),
                ("ISA_StopMentalBreaks".Translate(),StopMentalBreaks),
                ("ISA_MassTame".Translate(),        MassTame),
                ("ISA_FeedAllAnimals".Translate(),  FeedAllAnimals),
            };
            MenuHelper.Open("ISA_Master_NeedsMood".Translate(), items);
        }

        private void MaxAllNeeds()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if ((p.IsColonist || p.IsPrisonerOfColony) && p.needs != null)
                    foreach (var n in p.needs.AllNeeds)
                        n.CurLevelPercentage = 1f;
            }
            string msg = "ISA_NeedsMaximized".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void StopMentalBreaks()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (!p.IsColonist && !p.IsPrisonerOfColony) continue;
                if (p.InMentalState) p.MentalState?.RecoverFromState();
                if (p.needs?.mood != null)
                {
                    p.needs.mood.thoughts.memories.Memories.RemoveAll(m => m.MoodOffset() < 0f);
                    p.needs.mood.CurLevelPercentage = 1f;
                }
            }
            string msg = "ISA_MentalBreaksStopped".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void MassTame()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            int count = 0;
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned.ToList())
            {
                if (p.RaceProps.Animal && p.Faction == null)
                {
                    p.SetFaction(Faction.OfPlayer);
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_AnimalsTamed", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void FeedAllAnimals()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (p.RaceProps.Animal && p.needs?.food != null)
                    p.needs.food.CurLevelPercentage = 1f;
            }
            string msg = "ISA_AnimalsFed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  9) KOLONIE-MANAGER
        // ═══════════════════════════════════════════════════
        private void OpenColonyEnemy()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_RecruitAllPrisoners".Translate(), RecruitAllPrisoners),
                ("ISA_KillAllEnemies".Translate(),      KillAllEnemies),
                ("ISA_CleanMap".Translate(),            CleanMap),
                ("ISA_AddColonist".Translate(),         AddColonist),
            };
            MenuHelper.Open("ISA_Master_ColonyEnemy".Translate(), items);
        }

        private void RecruitAllPrisoners()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (p.IsPrisonerOfColony)
                {
                    p.guest?.SetGuestStatus(null, GuestStatus.Guest);
                    p.SetFaction(Faction.OfPlayer);
                }
            }
            string msg = "ISA_PrisonersRecruited".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void KillAllEnemies()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned.ToList())
            {
                if (GenHostility.HostileTo(p, Faction.OfPlayer) && !p.Dead)
                    p.Kill(null, null);
            }
            string msg = "ISA_EnemiesKilled".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void CleanMap()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var t in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.Corpse).ToList())
                t.Destroy();
            string msg = "ISA_MapCleaned".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void AddColonist()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var pk = PawnKindDefOf.Colonist;
            var pawn = PawnGenerator.GeneratePawn(new PawnGenerationRequest(
                pk, Faction.OfPlayer, PawnGenerationContext.NonPlayer,
                null, false, false, false, false, true,
                1f, false, true, false, true, true));
            var cell = DropCellFinder.TradeDropSpot(Find.CurrentMap);
            GenSpawn.Spawn(pawn, cell, Find.CurrentMap);
            string msg = "ISA_ColonistAdded".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  10) KARAWANEN-MANAGER
        // ═══════════════════════════════════════════════════
        private void OpenCaravanWorld()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_TeleportCaravans".Translate(), TeleportCaravans),
                ("ISA_FillCaravanFood".Translate(),  FillCaravanFood),
                ("ISA_RevealWorld".Translate(),      RevealWorld),
                ("ISA_HealCaravans".Translate(),     HealCaravans),
            };
            MenuHelper.Open("ISA_Master_CaravanWorld".Translate(), items);
        }

        private void TeleportCaravans()
        {
            int count = 0;
            foreach (var c in Find.WorldObjects.Caravans.ToList())
            {
                if (c.Faction == Faction.OfPlayer && c.pather != null && c.pather.Moving)
                {
                    c.Tile = c.pather.Destination;
                    c.pather.StopDead();
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_CaravansTeleported", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void FillCaravanFood()
        {
            int count = 0;
            foreach (var c in Find.WorldObjects.Caravans.ToList())
            {
                if (c.Faction == Faction.OfPlayer)
                {
                    var food = ThingMaker.MakeThing(ThingDefOf.MealSurvivalPack);
                    food.stackCount = 100;
                    CaravanInventoryUtility.GiveThing(c, food);
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_CaravanFoodFilled", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void RevealWorld()
        {
            foreach (var f in Find.FactionManager.AllFactionsListForReading)
                if (f.def != null) f.def.hidden = false;
            string msg = "ISA_WorldRevealed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void HealCaravans()
        {
            int healed = 0;
            foreach (var c in Find.WorldObjects.Caravans)
            {
                if (c.Faction != Faction.OfPlayer) continue;
                foreach (var p in c.pawns)
                {
                    foreach (var h in p.health.hediffSet.hediffs.ToList())
                        if (h.def.isBad || h is Hediff_MissingPart)
                            p.health.RemoveHediff(h);
                    healed++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_CaravansHealed", healed.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  11) ARCHOTECH-MANAGER
        // ═══════════════════════════════════════════════════
        private void OpenArchotechMech()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_HackMechs".Translate(),       HackMechs),
                ("ISA_ArtifactDelivery".Translate(), DeliverArtifacts),
                ("ISA_DroneSwarm".Translate(),       SpawnDroneSwarm),
                ("ISA_SpawnMechHerd".Translate(),    SpawnMechHerd),
            };
            MenuHelper.Open("ISA_Master_ArchotechMech".Translate(), items);
        }

        private void HackMechs()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            int count = 0;
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (p.RaceProps?.IsMechanoid == true && GenHostility.HostileTo(p, Faction.OfPlayer))
                {
                    p.stances?.stunner?.StunFor(5000, null, true, true);
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_MechsHacked", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void DeliverArtifacts()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var cell = DropCellFinder.TradeDropSpot(Find.CurrentMap);
            foreach (var defName in new[] { "MechSerumHealer", "MechSerumResurrector", "OrbitalBombardmentTargeter" })
            {
                var def = DefDatabase<ThingDef>.GetNamed(defName, false);
                if (def != null) GenSpawn.Spawn(ThingMaker.MakeThing(def), cell, Find.CurrentMap);
            }
            string msg = "ISA_ArtifactsDelivered".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void SpawnDroneSwarm()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var cell = DropCellFinder.TradeDropSpot(Find.CurrentMap);
            var pk = DefDatabase<PawnKindDef>.GetNamed("Mech_Scyther", false);
            if (pk == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            for (int i = 0; i < 3; i++)
            {
                var req = new PawnGenerationRequest(pk, Faction.OfPlayer, PawnGenerationContext.NonPlayer,
                    null, false, false, false, true, false, 1f, false, true, false, true, true,
                    false, false, false, false, 0f, 0f, null, 1f, null, null, null, null,
                    null, null, null, null, null, null, null, null, false, false, false, false,
                    null, null, null, null, null, 0f, DevelopmentalStage.Adult);
                GenSpawn.Spawn(PawnGenerator.GeneratePawn(req), cell, Find.CurrentMap);
            }
            string msg = "ISA_SwarmCalled".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void SpawnMechHerd()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var cell = DropCellFinder.TradeDropSpot(Find.CurrentMap);
            var pk = DefDatabase<PawnKindDef>.GetNamed("Mech_Centipede", false);
            if (pk == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var req = new PawnGenerationRequest(pk, Faction.OfPlayer, PawnGenerationContext.NonPlayer,
                null, false, false, false, true, false, 1f, false, true, false, true, true,
                false, false, false, false, 0f, 0f, null, 1f, null, null, null, null,
                null, null, null, null, null, null, null, null, false, false, false, false,
                null, null, null, null, null, 0f, DevelopmentalStage.Adult);
            GenSpawn.Spawn(PawnGenerator.GeneratePawn(req), cell, Find.CurrentMap);
            string msg = "ISA_MechHerdSpawned".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  12) SKILL-MEISTER
        // ═══════════════════════════════════════════════════
        private void OpenSkillMaster()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_MaxAllColonistSkills".Translate(),    MaxAllColonistSkills),
                ("ISA_MaxSelectedPawnSkills".Translate(),   MaxSelectedPawnSkills),
                ("ISA_SetPassion".Translate(),              OpenPassionMenu),
                ("ISA_GrantInspiration".Translate(),        GrantInspiration),
            };
            MenuHelper.Open("ISA_Master_SkillMaster".Translate(), items);
        }

        private void MaxAllColonistSkills()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.FreeColonists)
            {
                if (p.skills == null) continue;
                foreach (var sk in p.skills.skills)
                {
                    sk.Level = 20;
                    sk.passion = Passion.Major;
                }
            }
            string msg = "ISA_AllSkillsMaxed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void MaxSelectedPawnSkills()
        {
            var pawn = Find.Selector.SingleSelectedThing as Pawn;
            if (pawn?.skills == null)
            {
                TTS.Say("ISA_NoPawnSelected".Translate());
                return;
            }
            MaxSkills(pawn);
        }

        private void OpenPassionMenu()
        {
            var pawn = Find.Selector.SingleSelectedThing as Pawn;
            if (pawn?.skills == null)
            {
                TTS.Say("ISA_NoPawnSelected".Translate());
                return;
            }
            var passionItems = new List<(string, Action)>
            {
                ("ISA_PassionMinor".Translate(), () => SetPassion(pawn, Passion.Minor)),
                ("ISA_PassionMajor".Translate(), () => SetPassion(pawn, Passion.Major)),
                ("ISA_PassionNone".Translate(),  () => SetPassion(pawn, Passion.None)),
            };
            MenuHelper.Open("ISA_SetPassion".Translate(), passionItems);
        }

        private void SetPassion(Pawn pawn, Passion passion)
        {
            if (pawn.skills == null) return;
            foreach (var sk in pawn.skills.skills)
                sk.passion = passion;
            string msg = "ISA_PassionSet".Translate() + " " + passion.ToString();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void GrantInspiration()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var inspirationDef = DefDatabase<InspirationDef>.AllDefs.FirstOrDefault();
            if (inspirationDef == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.FreeColonists)
                p.mindState?.inspirationHandler?.TryStartInspiration(inspirationDef, null);
            string msg = "ISA_InspirationGranted".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  13) BASIS-INSTANDHALTUNG
        // ═══════════════════════════════════════════════════
        private void OpenBaseMaintenance()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_RepairAllBuildings".Translate(),    RepairAllBuildings),
                ("ISA_FinishAllConstruction".Translate(), FinishAllConstruction),
                ("ISA_RefuelAll".Translate(),             RefuelAll),
                ("ISA_RechargeAll".Translate(),           RechargeAll),
            };
            MenuHelper.Open("ISA_Master_BaseMaintenance".Translate(), items);
        }

        private void RepairAllBuildings()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            int count = 0;
            foreach (var t in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.BuildingArtificial).ToList())
            {
                if (t is Building b && b.HitPoints < b.MaxHitPoints)
                {
                    b.HitPoints = b.MaxHitPoints;
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_BuildingsRepaired", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void FinishAllConstruction()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var f in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.Blueprint).ToList())
            {
                if (f is Blueprint bp)
                    bp.TryReplaceWithSolidThing(null, out _, out _);
            }
            string msg = "ISA_ConstructionFinished".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void RefuelAll()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var t in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.BuildingArtificial).ToList())
            {
                var comp = t.TryGetComp<CompRefuelable>();
                comp?.Refuel(comp.Props.fuelCapacity - comp.Fuel);
            }
            string msg = "ISA_AllRefueled".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void RechargeAll()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            foreach (var t in Find.CurrentMap.listerThings.ThingsInGroup(ThingRequestGroup.BuildingArtificial).ToList())
            {
                var comp = t.TryGetComp<CompPowerBattery>();
                if (comp != null) comp.AddEnergy(comp.Props.storedEnergyMax - comp.StoredEnergy);
            }
            string msg = "ISA_AllRecharged".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  14) NATUR-KONTROLLE
        // ═══════════════════════════════════════════════════
        private void OpenNatureControl()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_MaxAllPlants".Translate(),    MaxAllPlants),
                ("ISA_RemoveAllWildAnimals".Translate(), RemoveWildAnimals),
                ("ISA_SpawnAnimalHerd".Translate(), OpenSpawnAnimalMenu),
                ("ISA_ChangeSeasonTick".Translate(), OpenSeasonMenu),
            };
            MenuHelper.Open("ISA_Master_NatureControl".Translate(), items);
        }

        private void MaxAllPlants()
        {
            MaxPlantGrowth();
        }

        private void RemoveWildAnimals()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            int count = 0;
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned.ToList())
            {
                if (p.RaceProps.Animal && p.Faction == null && !p.Dead)
                {
                    p.Destroy();
                    count++;
                }
            }
            string msg = TranslatorFormattedStringExtensions.Translate("ISA_WildAnimalsRemoved", count.ToString());
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenSpawnAnimalMenu()
        {
            var animalKinds = DefDatabase<PawnKindDef>.AllDefs
                .Where(pk => pk.RaceProps?.Animal == true)
                .OrderBy(pk => pk.label ?? pk.defName)
                .Select(pk =>
                {
                    string label = GenText.CapitalizeFirst(pk.label ?? pk.defName);
                    Action act = () => SpawnAnimalHerd(pk, 5);
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_SpawnAnimalHerd".Translate(), animalKinds);
        }

        private void SpawnAnimalHerd(PawnKindDef pk, int count)
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var cell = DropCellFinder.TradeDropSpot(Find.CurrentMap);
            for (int i = 0; i < count; i++)
            {
                var req = new PawnGenerationRequest(pk, null, PawnGenerationContext.NonPlayer,
                    null, false, false, false, false, false, 1f, false, true, false, true, true);
                GenSpawn.Spawn(PawnGenerator.GeneratePawn(req), cell, Find.CurrentMap);
            }
            string msg = count + "x " + (pk.label ?? pk.defName) + " " + "ISA_SpawnedSuffix".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenSeasonMenu()
        {
            var items = new List<(string, Action)>
            {
                ("ISA_SeasonSpring".Translate(), () => SkipToSeason(0)),
                ("ISA_SeasonSummer".Translate(), () => SkipToSeason(15000)),
                ("ISA_SeasonFall".Translate(),   () => SkipToSeason(30000)),
                ("ISA_SeasonWinter".Translate(), () => SkipToSeason(45000)),
            };
            MenuHelper.Open("ISA_ChangeSeasonTick".Translate(), items);
        }

        private void SkipToSeason(int targetTickInYear)
        {
            int yearLen = 3600000;
            int curTick = Find.TickManager.TicksGame % yearLen;
            int delta = targetTickInYear - curTick;
            if (delta < 0) delta += yearLen;
            Find.TickManager.DebugSetTicksGame(Find.TickManager.TicksGame + delta);
            TTS.Say("ISA_SeasonSkipped".Translate());
        }

        // ═══════════════════════════════════════════════════
        //  15) ROYALTY-PSYCAST (optional, falls DLC vorhanden)
        // ═══════════════════════════════════════════════════
        private void OpenRoyaltyPsycast()
        {
            var pawn = Find.Selector.SingleSelectedThing as Pawn;
            if (pawn == null)
            {
                TTS.Say("ISA_NoPawnSelected".Translate());
                return;
            }

            var items = new List<(string, Action)>
            {
                ("ISA_MaxPsyfocus".Translate(),   () => MaxPsyfocus(pawn)),
                ("ISA_GrantPsylink".Translate(),  () => GrantPsylink(pawn)),
                ("ISA_GrantRoyalTitle".Translate(),() => OpenGrantRoyalTitle(pawn)),
                ("ISA_UnlockAllPsycasts".Translate(), () => UnlockAllPsycasts(pawn)),
            };
            MenuHelper.Open("ISA_Master_RoyaltyPsycast".Translate() + ": " + pawn.LabelShort, items);
        }

        private void MaxPsyfocus(Pawn pawn)
        {
            if (pawn.psychicEntropy == null) { TTS.Say("ISA_NoPsychic".Translate()); return; }
            pawn.psychicEntropy.SetInitialPsyfocusLevel();
            pawn.psychicEntropy.TryAddEntropy(-pawn.psychicEntropy.EntropyValue, null, false, false);
            string msg = "ISA_PsyfocusMaxed".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void GrantPsylink(Pawn pawn)
        {
            var psylinkDef = DefDatabase<HediffDef>.GetNamed("PsychicAmplifier", false);
            if (psylinkDef == null) { TTS.Say("ISA_RoyaltyNotInstalled".Translate()); return; }
            if (pawn.health.hediffSet.HasHediff(psylinkDef))
            {
                // Increase level
                var h = pawn.health.hediffSet.GetFirstHediffOfDef(psylinkDef);
                (h as Hediff_Psylink)?.ChangeLevel(1, true);
            }
            else
            {
                pawn.health.AddHediff(psylinkDef);
            }
            string msg = "ISA_PsylinkGranted".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void OpenGrantRoyalTitle(Pawn pawn)
        {
            var empire = Find.FactionManager.AllFactionsListForReading
                .FirstOrDefault(f => f.def?.royalTitleTags?.Contains("Empire") == true);
            if (empire == null) { TTS.Say("ISA_RoyaltyNotInstalled".Translate()); return; }

            var titles = DefDatabase<RoyalTitleDef>.AllDefs
                .OrderBy(t => t.seniority)
                .Select(t =>
                {
                    string label = GenText.CapitalizeFirst(t.label ?? t.defName);
                    Action act = () =>
                    {
                        pawn.royalty?.SetTitle(empire, t, true, true, false);
                        string msg = "ISA_TitleGranted".Translate() + " " + label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_GrantRoyalTitle".Translate(), titles);
        }

        private void UnlockAllPsycasts(Pawn pawn)
        {
            if (pawn.abilities == null) { TTS.Say("ISA_NoPsychic".Translate()); return; }
            foreach (var ab in DefDatabase<AbilityDef>.AllDefs.Where(a => a.IsPsycast))
            {
                if (pawn.abilities.GetAbility(ab) == null)
                    pawn.abilities.GainAbility(ab);
            }
            string msg = "ISA_PsycastsUnlocked".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  16) BIOTECH-GENETIK
        // ═══════════════════════════════════════════════════
        private void OpenBiotechGenetics()
        {
            var pawn = Find.Selector.SingleSelectedThing as Pawn;
            if (pawn == null)
            {
                TTS.Say("ISA_NoPawnSelected".Translate());
                return;
            }

            var items = new List<(string, Action)>
            {
                ("ISA_AddGene".Translate(),       () => OpenAddGeneMenu(pawn)),
                ("ISA_RemoveGene".Translate(),    () => OpenRemoveGeneMenu(pawn)),
                ("ISA_ApplyXenotype".Translate(), () => OpenApplyXenotypeMenu(pawn)),
                ("ISA_MaxHemogen".Translate(),    () => MaxHemogen(pawn)),
            };
            MenuHelper.Open("ISA_Master_BiotechGenetics".Translate() + ": " + pawn.LabelShort, items);
        }

        private void OpenAddGeneMenu(Pawn pawn)
        {
            if (pawn.genes == null) { TTS.Say("ISA_BiotechNotInstalled".Translate()); return; }
            var genes = DefDatabase<GeneDef>.AllDefs
                .OrderBy(g => g.label ?? g.defName)
                .Select(g =>
                {
                    string label = GenText.CapitalizeFirst(g.label ?? g.defName);
                    Action act = () =>
                    {
                        pawn.genes.AddGene(g, true);
                        string msg = "ISA_GeneAdded".Translate() + " " + label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_AddGene".Translate(), genes);
        }

        private void OpenRemoveGeneMenu(Pawn pawn)
        {
            if (pawn.genes == null) { TTS.Say("ISA_BiotechNotInstalled".Translate()); return; }
            var genes = pawn.genes.GenesListForReading
                .Select(g =>
                {
                    string label = GenText.CapitalizeFirst(g.def.label ?? g.def.defName);
                    Action act = () =>
                    {
                        pawn.genes.RemoveGene(g);
                        string msg = "ISA_GeneRemoved".Translate() + " " + label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_RemoveGene".Translate(), genes);
        }

        private void OpenApplyXenotypeMenu(Pawn pawn)
        {
            if (pawn.genes == null) { TTS.Say("ISA_BiotechNotInstalled".Translate()); return; }
            var types = DefDatabase<XenotypeDef>.AllDefs
                .OrderBy(x => x.label ?? x.defName)
                .Select(x =>
                {
                    string label = GenText.CapitalizeFirst(x.label ?? x.defName);
                    Action act = () =>
                    {
                        pawn.genes.SetXenotype(x);
                        string msg = "ISA_XenotypeApplied".Translate() + " " + label;
                        Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
                        TTS.Say(msg);
                    };
                    return (label, act);
                }).ToList();
            MenuHelper.Open("ISA_ApplyXenotype".Translate(), types);
        }

        private void MaxHemogen(Pawn pawn)
        {
            var need = pawn.genes?.GetFirstGeneOfType<Gene_Hemogen>();
            if (need == null) { TTS.Say("ISA_NoPawnSelected".Translate()); return; }
            if (need != null) need.Value = need.Max;
            string msg = "ISA_HemogenMaxed".Translate() + " " + pawn.LabelShort;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        // ═══════════════════════════════════════════════════
        //  17) IDEOLOGY-GLAUBEN
        // ═══════════════════════════════════════════════════
        private void OpenIdeologyBelief()
        {
            var pawn = Find.Selector.SingleSelectedThing as Pawn;

            var items = new List<(string, Action)>
            {
                ("ISA_MaxCertainty".Translate(),      () => MaxCertainty(pawn)),
                ("ISA_ConvertAllColonists".Translate(), () => ConvertAll()),
                ("ISA_ApplyRitualRole".Translate(),   () => TTS.Say("ISA_NotImplemented".Translate())),
            };
            MenuHelper.Open("ISA_Master_IdeologyBelief".Translate(), items);
        }

        private void MaxCertainty(Pawn pawn)
        {
            if (pawn?.ideo == null)
            {
                // Alle Kolonisten
                if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
                foreach (var p in Find.CurrentMap.mapPawns.FreeColonists)
                    if (p.ideo != null) p.ideo.OffsetCertainty(1f);
            }
            else
            {
                pawn.ideo.OffsetCertainty(1f);
            }
            string msg = "ISA_CertaintyMaxed".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

        private void ConvertAll()
        {
            if (Find.CurrentMap == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            var playerIdeo = Faction.OfPlayer.ideos?.PrimaryIdeo;
            if (playerIdeo == null) { TTS.Say("ISA_IdeologyNotInstalled".Translate()); return; }
            foreach (var p in Find.CurrentMap.mapPawns.AllPawnsSpawned)
            {
                if (p.IsColonist && p.ideo != null)
                {
                    p.ideo.SetIdeo(playerIdeo);
                    p.ideo.OffsetCertainty(1f);
                }
            }
            string msg = "ISA_AllConverted".Translate();
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }
    }

    // ─────────────────────────────────────────────────────────
    //  Dialog: Menge eingeben und Item/Pawn spawnen
    // ─────────────────────────────────────────────────────────
    public class Dialog_SpawnQuantity : Window
    {
        private readonly ThingDef   _itemDef;
        private readonly ThingDef   _stuffDef;
        private readonly PawnKindDef _pawnKind;
        private string _buffer = "1";

        public override Vector2 InitialSize => new Vector2(360f, 180f);

        public Dialog_SpawnQuantity(ThingDef itemDef, ThingDef stuffDef, PawnKindDef pawnKind)
            : base(null)
        {
            _itemDef  = itemDef;
            _stuffDef = stuffDef;
            _pawnKind = pawnKind;
            doCloseX  = true;
            forcePause = true;
            closeOnClickedOutside = true;
        }

        public override void PreOpen()
        {
            base.PreOpen();
            string name = _itemDef != null
                ? (_itemDef.label ?? _itemDef.defName)
                : (_pawnKind?.label ?? _pawnKind?.defName ?? "?");
            TTS.Say("ISA_QuantityFor".Translate() + " " + name + ". " + "ISA_EnterQuantity".Translate());
        }

        public override void DoWindowContents(Rect inRect)
        {
            Text.Font = GameFont.Small;
            string name = _itemDef != null
                ? (_itemDef.label ?? _itemDef.defName)
                : (_pawnKind?.label ?? _pawnKind?.defName ?? "?");

            Widgets.Label(new Rect(0, 0, inRect.width, 28f), "ISA_QuantityFor".Translate() + " " + name + ":");
            _buffer = Widgets.TextField(new Rect(0, 34f, inRect.width, 30f), _buffer);

            if (Widgets.ButtonText(new Rect(0, 74f, inRect.width, 34f), "ISA_SpawnBtn".Translate()))
                TrySpawn();

            if (Event.current.type == EventType.KeyDown &&
                (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter))
            {
                TrySpawn();
                Event.current.Use();
            }
        }

        private void TrySpawn()
        {
            if (!int.TryParse(_buffer, out int qty) || qty <= 0)
            {
                Messages.Message("ISA_InvalidQuantity".Translate(), MessageTypeDefOf.RejectInput, false);
                TTS.Say("ISA_InvalidQuantity".Translate());
                return;
            }
            DoSpawn(qty);
            Close();
        }

        
        private void DoSpawn(int qty)
        {
            var map = Verse.Find.CurrentMap;
            if (map == null) { TTS.Say("ISA_NoValidTarget".Translate()); return; }
            
            Verse.IntVec3 cell = Verse.UI.MouseCell();
            if (!cell.InBounds(map)) 
            {
                cell = RimWorld.DropCellFinder.TradeDropSpot(map);
            }

            if (_pawnKind != null)
            {
                for (int i = 0; i < qty; i++)
                {
                    var req = new PawnGenerationRequest(_pawnKind, RimWorld.Faction.OfPlayer);
                    Verse.Pawn pawn = PawnGenerator.GeneratePawn(req);
                    Verse.GenSpawn.Spawn(pawn, cell, map);
                }
            }
            else if (_itemDef != null)
            {
                int stack = _itemDef.stackLimit > 0 ? _itemDef.stackLimit : 1;
                int rem   = qty;
                while (rem > 0)
                {
                    var t = Verse.ThingMaker.MakeThing(_itemDef, _stuffDef);
                    t.stackCount = UnityEngine.Mathf.Min(rem, stack);
                    Verse.GenSpawn.Spawn(t, cell, map);
                    rem -= t.stackCount;
                }
            }

            string name = _itemDef != null
                ? (_itemDef.label ?? _itemDef.defName)
                : (_pawnKind?.label ?? _pawnKind?.defName ?? "?");
            string msg = qty + "x " + name + " " + "ISA_SpawnedSuffix".Translate();
            Verse.Messages.Message(msg, RimWorld.MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
        }

    }

    // ─────────────────────────────────────────────────────────
    //  Dialog: Pawn-Alter setzen
    // ─────────────────────────────────────────────────────────
    public class Dialog_SetAge : Window
    {
        private readonly Pawn _pawn;
        private string _buffer = "25";

        public override Vector2 InitialSize => new Vector2(320f, 150f);

        public Dialog_SetAge(Pawn pawn) : base(null)
        {
            _pawn = pawn;
            doCloseX  = true;
            forcePause = true;
            closeOnClickedOutside = true;
        }

        public override void PreOpen()
        {
            base.PreOpen();
            TTS.Say("ISA_SetAge".Translate() + ": " + _pawn.LabelShort);
        }

        public override void DoWindowContents(Rect inRect)
        {
            Widgets.Label(new Rect(0, 0, inRect.width, 28f), "ISA_SetAge".Translate() + " " + _pawn.LabelShort + ":");
            _buffer = Widgets.TextField(new Rect(0, 34f, inRect.width, 30f), _buffer);

            if (Widgets.ButtonText(new Rect(0, 74f, inRect.width, 34f), "ISA_ConfirmAge".Translate()))
                TrySetAge();

            if (Event.current.type == EventType.KeyDown &&
                (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter))
            {
                TrySetAge();
                Event.current.Use();
            }
        }

        private void TrySetAge()
        {
            if (!int.TryParse(_buffer, out int age) || age < 0)
            {
                TTS.Say("ISA_InvalidQuantity".Translate());
                return;
            }
            long ticks = (long)age * 3600000L;
            _pawn.ageTracker.AgeBiologicalTicks = ticks;
            _pawn.ageTracker.AgeChronologicalTicks = ticks;
            string msg = "ISA_AgeSet".Translate() + " " + _pawn.LabelShort + " " + age;
            Messages.Message(msg, MessageTypeDefOf.PositiveEvent, false);
            TTS.Say(msg);
            Close();
        }
    }
}
